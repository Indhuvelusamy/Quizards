package com.example.quizards;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.Vector;

public class mba extends AppCompatActivity {

    TextView tv;
    Button submitbutton, quitbutton;
    RadioGroup radio_g;
    RadioButton rb1,rb2,rb3,rb4;
    private TextView textViewCountDown;
    public static int marks=0,correct=0,wrong=0;
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mba);
        Vector<Integer> list=new Vector<Integer>(10);
        for(int i1=0;i1<20;i1++)
            list.add(i1);
        Collections.shuffle(list);
        int []i= new int[10];
        for(int i1=0;i1<10;i1++)
            i[i1]=list.get(i1);
        String questions1[] = {
                "If the side of the square increases by 40%, then the area of the square increases by",
                "If 28 cartons of a juice cost Rs.21, then 7 cartons would cost ?",
                "A worker is paid Rs. 20 for each day he works, and he is paid proportionately for any fraction of a day he works. If during one week he works, 1/8, 2/3, ¾, 1/3 and 1 full day, what are his total earnings for the week ?",
                "If the product of 3 consecutive integers is 210 then the sum of the two smaller integers is",
                "Dal costs 1/3 as much as rice, rice costs 5/4 as much as eggs. Eggs cost what fraction of the cost of dal ",
                "Which of the following integers has the most divisors ?",
                "Successive discounts of 20% and 15% are equal to a single discount of",
                "If a diesel hose A can fill a car tank in 20 minutes and a diesel hose B can fill up the same tank in 15 minutes, how long will it take for the two hoses to fill the car tank together ?",
                "If x/y = 4 and y is not 0, what percentage (to the nearest percent) of x is 2x-y ?",
                "If 31% of a number of 46.5 the number is",
                "He was charged --------- a whole series of crimes",
                "It is difficult to ------------ her nonsense",
                "His name has become a synonym ------- evil",
                "There is the book that you asked",
                "I get up everyday ------- 5 o‟ clock",
                "Waylay",
                "Thespian",
                "Regal",
                "Tepid",
                "Tenacity",
        };
        String answers1[] = {"96%","Rs.5.25","Rs.57.5","11","12/5","88","32%","60/7 minutes","175","150","with","get along with","of","for","by","ambush","actor","Royal","Luckewarm","Perseverance"
        };
        String opt1[] = {
                "16%","40%","96%","116%",
                "Rs.5.25","Rs.5.5","Rs.6.4","Rs.7",
                "Rs.40.75","Rs.52.5","Rs.54","Rs.57.5",
                "5","11","12","13",
                "5/12","4/5","5/4","12/5",
                "88","91","95","99",
                "30%","32%","34%","35%",
                "5 minutes","15/2 minutes","60/7 minutes","65/7 minutes",
                "25","57","75","175",
                "150","155","160","165",
                "for","with","by","on",
                "put up with","pull through","get along with","put out",
                "within","from","of","in",
                "for","of","after","at",
                "about","from","by","at",
                "road map","ambush","journey","direction",
                "actor","daydreamer","magician","oldman",
                "Basic","Legal","Major","Royal",
                "Boiling","Freezing","Gaseous","Luckewarm",
                "Ingratitude","Decimation","Splendor","Perseverance"

        };

        String []questions= new String[10];
        for(int i1=0;i1<10;i1++)
            questions[i1]=questions1[i[i1]];
        String []answers= new String[10];
        for(int i1=0;i1<10;i1++)
            answers[i1]=answers1[i[i1]];
        String []opt= new String[40];
        int j1=0;
        for(int i1=0;i1<10;i1++)
        {

            int j=i[i1]*4;
            for(int k=0; k<4;k++) {
                opt[j1] = opt1[j];
                j++;
                j1++;
            }

        }


        final TextView score = (TextView)findViewById(R.id.textView4);
        TextView textView=(TextView)findViewById(R.id.DispName);
        Intent intent = getIntent();
       /* String name= intent.getStringExtra("myname");

        if (name.trim().equals(""))
            textView.setText("Hello User");
        else
            textView.setText("Hello " + name);*/

        submitbutton=(Button)findViewById(R.id.button3);
        quitbutton=(Button)findViewById(R.id.buttonquit);
        tv=(TextView) findViewById(R.id.tvque);

        radio_g=(RadioGroup)findViewById(R.id.answersgrp);
        rb1=(RadioButton)findViewById(R.id.radioButton);
        rb2=(RadioButton)findViewById(R.id.radioButton2);
        rb3=(RadioButton)findViewById(R.id.radioButton3);
        rb4=(RadioButton)findViewById(R.id.radioButton4);
        tv.setText(questions[flag]);
        rb1.setText(opt[0]);
        rb2.setText(opt[1]);
        rb3.setText(opt[2]);
        rb4.setText(opt[3]);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(radio_g.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(getApplicationContext(), "Please select one choice", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton uans = (RadioButton) findViewById(radio_g.getCheckedRadioButtonId());
                String ansText = uans.getText().toString();
//                Toast.makeText(getApplicationContext(), ansText, Toast.LENGTH_SHORT).show();
                if(ansText.equals(answers[flag])) {
                    correct++;
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                }
                else {
                    wrong++;
                    Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                }

                flag++;

                if (score != null)
                    score.setText(""+correct);

                if(flag<questions.length)
                {
                    tv.setText(questions[flag]);
                    rb1.setText(opt[flag*4]);
                    rb2.setText(opt[flag*4 +1]);
                    rb3.setText(opt[flag*4 +2]);
                    rb4.setText(opt[flag*4 +3]);
                }
                else
                {
                    marks=correct;
                    Intent in = new Intent(getApplicationContext(),result4.class);
                    startActivity(in);
                }
                radio_g.clearCheck();
            }
        });

        quitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),result4.class);
                startActivity(intent);
            }
        });
    }

}