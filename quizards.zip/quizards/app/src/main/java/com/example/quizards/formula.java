package com.example.quizards;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.app.Activity;

public class formula extends Activity {

    ListView a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula);

        a = findViewById(R.id.lv);
        Button b1=(Button)findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(getApplicationContext(),home.class);
                startActivity(intent);

            }
        });
        String x[]={"AGE","AVERAGE","CLOCK","H.C.F and L.C.M","PROBLEMS ON NUMBERS"};
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, x);

        a.setAdapter(dataAdapter);

        a.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String t;
                t = (String) a.getItemAtPosition(i);
                Toast.makeText(getApplicationContext(),t,Toast.LENGTH_LONG).show();
                if(i==0)
                {
                    Intent intent=new Intent(getApplicationContext(),age.class);
                    startActivity(intent);
                }
                if(i==1)
                {
                    Intent intent=new Intent(getApplicationContext(),average.class);
                    startActivity(intent);
                }
                if(i==2)
                {
                    Intent intent=new Intent(getApplicationContext(),clock.class);
                    startActivity(intent);
                }
                if(i==3)
                {
                    Intent intent=new Intent(getApplicationContext(),lcm.class);
                    startActivity(intent);
                }
                if(i==4)
                {
                    Intent intent=new Intent(getApplicationContext(),number.class);
                    startActivity(intent);
                }

            }
        });
    }
}
