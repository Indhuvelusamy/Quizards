package com.example.quizards;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.Vector;

public class gate extends AppCompatActivity {

    TextView tv;
    Button submitbutton, quitbutton;
    RadioGroup radio_g;
    RadioButton rb1,rb2,rb3,rb4;
    private TextView textViewCountDown;
    public static int marks=0,correct=0,wrong=0;
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gate);
        Vector<Integer> list=new Vector<Integer>(10);
        for(int i1=0;i1<20;i1++)
            list.add(i1);
        Collections.shuffle(list);
        int []i= new int[10];
        for(int i1=0;i1<10;i1++)
            i[i1]=list.get(i1);
        String questions1[] = {
                "If the angles of a pentagon are in the ratio 1:3:6:7:10, then the smallest angle is",
                "Turn odd man out 41, 43, 47, 53, 61, 71, 73, 81",
                "Complete the series 2, 5, 9, 19, 37, ………",
                "The calendar for 1990 is the same as for",
                "What is the smallest number by which 3600 is divided to make it a perfect cube ?",
                "Which of the following integers has the most divisors ?",
                "Successive discounts of 20% and 15% are equal to a single discount of",
                "If a diesel hose A can fill a car tank in 20 minutes and a diesel hose B can fill up the same tank in 15 minutes, how long will it take for the two hoses to fill the car tank together ?",
                "If x/y = 4 and y is not 0, what percentage (to the nearest percent) of x is 2x-y ?",
                "If 31% of a number of 46.5 the number is",
                "He was charged --------- a whole series of crimes",
                "It is difficult to ------------ her nonsense",
                "His name has become a synonym ------- evil",
                "There is the book that you asked",
                "I get up everyday ------- 5 o‟ clock",
                "Waylay",
                "Thespian",
                "Regal"
        };
        String answers1[] = {
                "20","81","75","1997","450","88","32%","60/7 minutes","175","150","with","get along with","of","for","by","ambush","actor","Royal"
        };
        String opt1[] = {
                "32","30","27","20",
                "61","71","73","81",
                "76","74","75","73",
                "1996","1997","1994","2000",
                "9","50","450","300",
                "88","91","95","99",
                "30%","32%","34%","35%",
                "5 minutes","15/2 minutes","60/7 minutes","65/7 minutes",
                "25","57","75","175",
                "150","155","160","165",
                "for","with","by","on",
                "put up with","pull through","get along with","put out",
                "within","from","of","in",
                "for","of","after","at",
                "about","from","by","at",
                "road map","ambush","journey","direction",
                "actor","daydreamer","magician","oldman",
                "Basic","Legal","Major","Royal",
                "Boiling","Freezing","Gaseous","Luckewarm",
                "Ingratitude","Decimation","Splendor","Perseverance"

        };

        String []questions= new String[10];
        for(int i1=0;i1<10;i1++)
            questions[i1]=questions1[i[i1]];
        String []answers= new String[10];
        for(int i1=0;i1<10;i1++)
            answers[i1]=answers1[i[i1]];
        String []opt= new String[40];
        int j1=0;
        for(int i1=0;i1<10;i1++)
        {

            int j=i[i1]*4;
            for(int k=0; k<4;k++) {
                opt[j1] = opt1[j];
                j++;
                j1++;
            }

        }


        final TextView score = (TextView)findViewById(R.id.textView4);
        TextView textView=(TextView)findViewById(R.id.DispName);
        Intent intent = getIntent();
       /* String name= intent.getStringExtra("myname");

        if (name.trim().equals(""))
            textView.setText("Hello User");
        else
            textView.setText("Hello " + name);*/

        submitbutton=(Button)findViewById(R.id.button3);
        quitbutton=(Button)findViewById(R.id.buttonquit);
        tv=(TextView) findViewById(R.id.tvque);

        radio_g=(RadioGroup)findViewById(R.id.answersgrp);
        rb1=(RadioButton)findViewById(R.id.radioButton);
        rb2=(RadioButton)findViewById(R.id.radioButton2);
        rb3=(RadioButton)findViewById(R.id.radioButton3);
        rb4=(RadioButton)findViewById(R.id.radioButton4);
        tv.setText(questions[flag]);
        rb1.setText(opt[0]);
        rb2.setText(opt[1]);
        rb3.setText(opt[2]);
        rb4.setText(opt[3]);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(radio_g.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(getApplicationContext(), "Please select one choice", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton uans = (RadioButton) findViewById(radio_g.getCheckedRadioButtonId());
                String ansText = uans.getText().toString();
//                Toast.makeText(getApplicationContext(), ansText, Toast.LENGTH_SHORT).show();
                if(ansText.equals(answers[flag])) {
                    correct++;
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                }
                else {
                    wrong++;
                    Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                }

                flag++;

                if (score != null)
                    score.setText(""+correct);

                if(flag<questions.length)
                {
                    tv.setText(questions[flag]);
                    rb1.setText(opt[flag*4]);
                    rb2.setText(opt[flag*4 +1]);
                    rb3.setText(opt[flag*4 +2]);
                    rb4.setText(opt[flag*4 +3]);
                }
                else
                {
                    marks=correct;
                    Intent in = new Intent(getApplicationContext(),result7.class);
                    startActivity(in);
                }
                radio_g.clearCheck();
            }
        });

        quitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),result7.class);
                startActivity(intent);
            }
        });
    }

}