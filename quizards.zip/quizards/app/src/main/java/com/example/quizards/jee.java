package com.example.quizards;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.Vector;

public class jee extends AppCompatActivity {

    TextView tv;
    Button submitbutton, quitbutton;
    RadioGroup radio_g;
    RadioButton rb1, rb2, rb3, rb4;
    private TextView textViewCountDown;
    public static int marks = 0, correct = 0, wrong = 0;
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jee);
        Vector<Integer> list = new Vector<Integer>(10);
        for (int i1 = 0; i1 < 22; i1++)
            list.add(i1);
        Collections.shuffle(list);
        int[] i = new int[10];
        for (int i1 = 0; i1 < 10; i1++)
            i[i1] = list.get(i1);
        String questions1[] = {
                "If the angles of a pentagon are in the ratio 1:3:6:7:10, then the smallest angle is",
                "Turn odd man out 41, 43, 47, 53, 61, 71, 73, 81",
                "Complete the series 2, 5, 9, 19, 37, ………",
                "The calendar for 1990 is the same as for",
                "What is the smallest number by which 3600 is divided to make it a perfect cube ?",
                "What price should a shopkeeper mark on an article, costing him Rs.153, to gain 20% after allowing a discount of 15%",
                "The operating system for the laptop compi called Machite is",
                "The errors that can be pointed out by compiler are",
                "Which of the following colour graphics dia adapter has the highest resohition ?",
                "The programming language used in Artil Intelligence and expert system development",
                "Whose trademark is the operating sy: UNIX ?",
                "Which tanguage has recently becamt defacto standard for interfacing applic programs ivith relational database system",
                "The number obtained by reverting the digits is 594 less than the original number. The number is",
                "Twenty men can finish a piece of work in 30 days. When should 5 men leave the work so that it may be finished in 35 days",
                "The value of a machine depreciates from Rs. 32,768 to Rs. 21,952 in three years. What is the rate % of depreciation ?",
                "If x2 - 3x + 2 is a factor of x4 - px2 +q, then the value of p and q respectively will be",
                "The rational numbers lying between (1/3) and (3/4) are",
                "Find the greatest number that will divide 1625, 2281 and 4218 leaving remainders 8, 4, 5 respectively",
                "The area of a grassy plot is 480 metres. If each side has been 5m longer, the area would have been increased by 245 sq. m. Find the length of the fence to surround it",
                "The diagonals of a rhombus are 60 m and 80 m. Its area would be",
                "The average age of 32 students is 10 years. If the teachers age is also included, the average age increases by one year. What is the age of the teacher ?",
                "The string of a kite is 150 metres long and it makes an angle of 60° with the horizontal, the height of the kite from the ground would be"

        };
        String answers1[] = {
                "20","81","75","1997","450","Rs. 216","OZ","Logical errors","VGA","PROLOG","BELL laboratories","SQL","258","15 days","12.5%","5,4","117/300","11","88","2400 sq. m","43","129.9m"

        };
        String opt1[] = {
                "32","30","27","20",
                "61","71","73","81",
                "76","74","75","73",
                "1996","1997","1994","2000",
                "9","50","450","300",
                "Rs. 224","Rs. 216","Rs. 184","Rs. 162",
                "Windows","DOS","MS-DOS","OZ",
                "Syntax errors","Semantic errors","Logical errors","Intemal errors",
                "CGA","HGA","EGA","VGA",
                "RPG","PROLOG","FORTRAN"," C + +",
                "BELL Laboratories","Ashton Tate","Microsoft","Motorola",
                "ORACLE","SQL","dBASE","4GL",
                "762","258","528","852",
                "10 days","20 days","25days","l5 days",
                "11%","12.5%","33%","12.25%",
                "-5, 4","-5, -4","5, 4","5, -4",
                "117/300, 287/400","97/300, 299/500","99/300, 301/400","95/300, 301/400",
                "11","12","13","14",
                "87","88","90","92",
                "1000 sq. m","3600 sq. m","2400 sq. m","4800 sq. m",
                "50","34","43","32",
                "130.1m","129.9m","112 m","75 m"
        };

        String[] questions = new String[10];
        for (int i1 = 0; i1 < 10; i1++)
            questions[i1] = questions1[i[i1]];
        String[] answers = new String[10];
        for (int i1 = 0; i1 < 10; i1++)
            answers[i1] = answers1[i[i1]];
        String[] opt = new String[40];
        int j1 = 0;
        for (int i1 = 0; i1 < 10; i1++) {

            int j = i[i1] * 4;
            for (int k = 0; k < 4; k++) {
                opt[j1] = opt1[j];
                j++;
                j1++;
            }

        }


        final TextView score = (TextView) findViewById(R.id.textView4);
        TextView textView = (TextView) findViewById(R.id.DispName);
        Intent intent = getIntent();
       /* String name= intent.getStringExtra("myname");

        if (name.trim().equals(""))
            textView.setText("Hello User");
        else
            textView.setText("Hello " + name);*/

        submitbutton = (Button) findViewById(R.id.button3);
        quitbutton = (Button) findViewById(R.id.buttonquit);
        tv = (TextView) findViewById(R.id.tvque);

        radio_g = (RadioGroup) findViewById(R.id.answersgrp);
        rb1 = (RadioButton) findViewById(R.id.radioButton);
        rb2 = (RadioButton) findViewById(R.id.radioButton2);
        rb3 = (RadioButton) findViewById(R.id.radioButton3);
        rb4 = (RadioButton) findViewById(R.id.radioButton4);
        tv.setText(questions[flag]);
        rb1.setText(opt[0]);
        rb2.setText(opt[1]);
        rb3.setText(opt[2]);
        rb4.setText(opt[3]);
        submitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (radio_g.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getApplicationContext(), "Please select one choice", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton uans = (RadioButton) findViewById(radio_g.getCheckedRadioButtonId());
                String ansText = uans.getText().toString();
//                Toast.makeText(getApplicationContext(), ansText, Toast.LENGTH_SHORT).show();
                if (ansText.equals(answers[flag])) {
                    correct++;
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                } else {
                    wrong++;
                    Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                }

                flag++;

                if (score != null)
                    score.setText("" + correct);

                if (flag < questions.length) {
                    tv.setText(questions[flag]);
                    rb1.setText(opt[flag * 4]);
                    rb2.setText(opt[flag * 4 + 1]);
                    rb3.setText(opt[flag * 4 + 2]);
                    rb4.setText(opt[flag * 4 + 3]);
                } else {
                    marks = correct;
                    Intent in = new Intent(getApplicationContext(), result6.class);
                    startActivity(in);
                }
                radio_g.clearCheck();
            }
        });

        quitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), result6.class);
                startActivity(intent);
            }
        });
    }
}